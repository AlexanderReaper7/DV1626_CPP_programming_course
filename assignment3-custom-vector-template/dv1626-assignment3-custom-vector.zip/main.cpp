#include <iostream>

int main()
{
    std::cout << "Create a wishlist with your new vector! :)" << std::endl;
    return 0;
}